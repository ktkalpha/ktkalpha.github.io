<script>
  import LogoAndTitle from './components/LogoAndTitle.vue'
  import ProfileAndDescription from './components/ProfileAndDescription.vue'
  import MyImages from './components/MyImages.vue'
  export default {
    data(){
      return {

      }
    },
    components: {
      LogoAndTitle : LogoAndTitle,
      ProfileAndDescription: ProfileAndDescription,
      MyImages: MyImages,
    }
  }
</script>

<template>

<LogoAndTitle />
<ProfileAndDescription />
<MyImages />
<Todo/>

</template>

<style>
*{
  background-color: #fafafa;
}
</style>
