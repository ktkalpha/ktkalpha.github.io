<template>
    <p>Learning</p>
    <div class="container">
        <div class="item"><img class="content" src="https://w.namu.la/s/6f8695350c52d8a6f07a30787fdd07ed65e77e010c16732832924d0effa75207dccdd972b8c7f5b9e7077c006e48cadde42f66172c11432a3c92e4407b4fcfdc7cef5dde26fddf9ae4c5f1baf95c79c3facf893a137887a4b498837c785bc6e5" alt=""></div>
        <div class="item"><img class="content" src="https://w.namu.la/s/779cac1a9257c783d10934e258d7ef27388764ce11ca11a6ba183cd17aa68c087262456000c7c302580062725157aac289938874b87037a9ee56ee7a417c1ce4da87844eb66bc2f77469167f989f178273d9d178466b41b13392d03062e64f3b" alt=""></div>
        <div class="item"><img class="content" src="https://w.namu.la/s/18f590719ba62222718f1a68efcad20118c422b146650c97162d782ef9995d28326d1011cfb37595d9c60d66a05b343556e520204383d4429456fb54ca6bbf5a3d924e7510ba24e9d8a7de3853f8d2a378e2aa833c608fd59186900cde53de30" alt="" srcset=""></div>
        <div class="item"><img class="content" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Python-logo-notext.svg/115px-Python-logo-notext.svg.png?20220821155029" alt="" srcset=""></div>
        <div class="item"><img class="content" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Vue.png/220px-Vue.png" alt="" srcset=""></div>
        <div class="item"><p></p>And More!</div>  
    </div>
    <p>Games</p>
    <div class="container">
        <div class="item"><img style="margin-top: 20px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/FortniteLogo.svg/250px-FortniteLogo.svg.png" alt=""></div>
        <div class="item"><img class="content2" src="https://www.minecraft.net/content/dam/games/minecraft/logos/logo-minecraft.svg" alt=""></div>
    </div>
    <p>Web app</p>
    <div class="container">
        <div class="item">
            <form action="https://ktkalpha.github.io/simple-todo-app/">
                <input class="button" type="submit" value="Simple Todo App" />
            </form>
        </div>
        <div class="item">
            <form action="https://ktkalpha.github.io/BigMac/">
                <input class="button" type="submit" value="Big mac" />
            </form>
        </div>
    </div>
</template>

<style>
.content2{
    height: 100px;
    width: 200px;
}
.content{
    width: 100px;
    height: 100px;
}
.container {
    display: grid;
    grid-template-columns: repeat( auto-fit, minmax(250px, 1fr) );
}
.item {
  background-color: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(43, 36, 36, 0.8);
  /* padding: 10rem; */
  font-size: 30px;
  text-align: center;
}

</style>