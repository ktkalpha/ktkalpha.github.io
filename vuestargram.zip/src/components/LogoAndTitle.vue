<script>
export default {
    data() {
        return {
            search: ''
        }
    },
    methods: {
        searchGoogle() {
            window.open("https://www.google.com/search?q="+this.search)
        }
    },
}
</script>

<template>
    <div class="border">
        <div id="logo"><img src="../assets/logo.svg"></div>
        <div id="title">Vuestagram</div>  
        <input v-model="search" class="search" placeholder="Search in Google..." />
        <button style="height: 37px;" @click="searchGoogle">🔍</button>
    </div>
</template>

<style>
@import url("https://fonts.googleapis.com/css?family=Fira Code");
*{
    font-family: 'Fira Code';
}
.search{
    margin-left: 2rem;    
}
.center {
  margin: auto;
  width: 60%;
  border: 3px solid #73AD21;
  padding: 10px;
}
#title, #logo, .search, .btnsearch
{
    vertical-align: middle;
    font-size: x-large;
    display:inline-block;
}
#logo{
    width: 3rem;
}
.border{
    border-bottom: solid #e6e6e6;
}
</style>