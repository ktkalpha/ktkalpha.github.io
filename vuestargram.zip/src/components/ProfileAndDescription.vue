<script>
</script>

<template>
    <div class="middle">
        <a href="https://github.com/ktkalpha"><img class="profile" src="../assets/channels4_profile.jpg"></a>
        <p class="name">Ko Tae Kyoung(고태경)</p>
        <p class="description">an aspiring programmer 🚀</p>
    </div>
</template>

<style>
.description{
    color: #3b3b3b;
    transform: translate(8rem,-2rem);
}
.name{
    font-weight: bold;
    font-size: x-large;
    transform: translate(10%,-130%);
}
.middle, .profile, .name{
    display: inline-block;
}
.profile{
    border-radius: 100%;
    margin-top:  3rem;
}

</style>